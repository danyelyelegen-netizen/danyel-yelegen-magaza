DANYEL YELEGEN – D1 bağlı müşteri mağazası

Bu sürüm:
- Ürünleri D1 veritabanından okur.
- Müşterinin ürün eklemesini/değiştirmesini içermez.
- Müşteri; adminin tanımladığı renk ve bedenleri seçebilir.
- Özelleştirilebilir ürünlerde yazı/numara ve logo/görsel önizlemesi yapabilir.
- Sepet ve WhatsApp sipariş metni oluşturur.

KURULUM:
1) Cloudflare Workers & Pages > danyel-yelegen-magaza > yeni deployment/upload ile bu klasörü deploy et.
2) Worker Settings > Bindings bölümünde D1 Database binding ekle:
   Variable name: DB
   Database: danyel-yelegen-db
3) Siteyi Visit ile aç ve kontrol et.

Not: WhatsApp numarası henüz verilmediği için sipariş butonu numarasız WhatsApp paylaşım bağlantısı kullanır.
